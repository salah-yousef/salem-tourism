import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-with-us',
  templateUrl: './book-with-us.component.html',
  styleUrls: ['./book-with-us.component.css']
})
export class BookWithUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
