import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-packages',
  templateUrl: './our-packages.component.html',
  styleUrls: ['./our-packages.component.css']
})
export class OurPackagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
