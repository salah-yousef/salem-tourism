import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-our-testimonials',
  templateUrl: './our-testimonials.component.html',
  styleUrls: ['./our-testimonials.component.css']
})
export class OurTestimonialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
