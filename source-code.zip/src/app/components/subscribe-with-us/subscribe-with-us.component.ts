import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscribe-with-us',
  templateUrl: './subscribe-with-us.component.html',
  styleUrls: ['./subscribe-with-us.component.css']
})
export class SubscribeWithUsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
